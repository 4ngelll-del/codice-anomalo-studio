# 📂 EXPEDIENTE #CA-117 — LA ANOMALÍA SUBMARINA DEL MAR BÁLTICO A 87 METROS

- **Día y Hora Programada (Zona Horaria México):** Sábado a las **15:00 hrs (CDMX)** (Debate & Guardados)
- **Nicho Editorial:** Misterios Sin Resolver (`EXPEDIENTE ABIERTO`)
- **Palabra Clave de Automatización (ManyChat / DM):** `BALTICO`
- **Puntuación de Auditoría Multi-Agente:** Originalidad 100% | Retención 96% | Brand Safety 100% | Conversión 96%

---

## 📝 1. CAPTION OFICIAL PARA COPIAR Y PEGAR EN INSTAGRAM

```text
📂 EXPEDIENTE #CA-117: LA ANOMALÍA SUBMARINA DEL MAR BÁLTICO A 87 METROS

En junio de 2011, el equipo de exploración sueco Ocean X liderado por Peter Lindberg y Dennis Åsberg escaneó el estrecho de Botnia con sonar de barrido lateral y detectó un objeto circular de 60 metros.

🔬 LA EVIDENCIA CLAVE:
Las inmersiones revelaron una mole elevada 4 metros sobre el lecho marino con corredores rectilíneos de 90 grados, formaciones escalonadas y una estela de nivelación de 300 metros detrás.

👇 ABRO DEBATE EN COMENTARIOS:
Mientras geólogos de la Universidad de Estocolmo analizaron muestras de basalto sugiriendo un depósito glacial del Pleistoceno, su simetría geométrica sigue siendo uno de los grandes debates submarinos.

⚡ Comenta la palabra "BALTICO" y nuestro sistema automático te enviará por DM el dossier extendido, el paper/estudio original y el material complementario.

🔖 Guarda este expediente en tu colección privada para consultarlo más tarde y compártelo en tus historias.

#CodiceAnomalo #MisteriosSinResolver #CienciaYTeoria #MisteriosDocumentados #TecnologiaExtrema #Futurologia #DatosInsolitos
```

---

## 🎬 2. GUION DE REEL COMPLEMENTARIO (15 SEGUNDOS — PUENTE DE TRÁFICO AL CARRUSEL)

> **Instrucción de grabación / IA de video:** Usa las imágenes generadas en esta carpeta con efecto Ken Burns (zoom lento) y voz profunda documental:
>
> **Guion:** "A 87 metros de profundidad en el Mar Báltico, un sonar sueco captó una estructura circular de 60 metros con ángulos de 90 grados y una marca de arrastre en el fondo marino. Mira las imágenes del sonar en el carrusel y comenta BALTICO."

---

## 💰 3. ESTRATEGIA DE MONETIZACIÓN Y AUDITORÍA DE ESTE CARRUSEL

- **Ángulo de Monetización:** Documentales de Exploración / Equipos Submarinos / Podcast de Misterios
- **Dictamen de los 4 Agentes:** Contrasta las imágenes de sonar de Ocean X (2011) con el análisis petrográfico de Volker Brüchert (Universidad de Estocolmo).

---

## 🖼️ 4. ESTRUCTURA DETALLADA DE LAS 5 IMÁGENES (1080×1350px 4:5)

### Slide 01 — GANCHO VIRAL
- **Titular:** LA ANOMALÍA SUBMARINA DEL MAR BÁLTICO A 87 METROS
- **Cuerpo:** El barrido de sonar que reveló un disco de 60 metros con ángulos rectos. El 99% de las personas desconoce los datos verificados detrás de este expediente científico.
- **Callout Inferior:** DESLIZA PARA ABRIR EL EXPEDIENTE →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `High-resolution amber side-scan sonar telemetry and deep-sea ROV spotlight revealing a 60-meter circular monolithic formation on the dark Baltic seafloor, 8k`

### Slide 02 — CONTEXTO IMPACTANTE
- **Titular:** 01 // EL HALLAZGO DOCUMENTADO
- **Cuerpo:** En junio de 2011, el equipo de exploración sueco Ocean X liderado por Peter Lindberg y Dennis Åsberg escaneó el estrecho de Botnia con sonar de barrido lateral y detectó un objeto circular de 60 metros.
- **Callout Inferior:** DATO VERIFICADO // EXPEDIENTE #CA-117
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `High-resolution amber side-scan sonar telemetry and deep-sea ROV spotlight revealing a 60-meter circular monolithic formation on the dark Baltic seafloor, 8k, close-up detail shot with technical telemetry overlay`

### Slide 03 — EL GIRO / EVIDENCIA
- **Titular:** 02 // LA ANOMALÍA QUE ROMPE LA LÓGICA
- **Cuerpo:** Las inmersiones revelaron una mole elevada 4 metros sobre el lecho marino con corredores rectilíneos de 90 grados, formaciones escalonadas y una estela de nivelación de 300 metros detrás.
- **Callout Inferior:** AQUÍ ES DONDE TODO CAMBIA →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `High-resolution amber side-scan sonar telemetry and deep-sea ROV spotlight revealing a 60-meter circular monolithic formation on the dark Baltic seafloor, 8k, dramatic side angle showing internal mechanism or anomaly`

### Slide 04 — CLÍMAX & DEBATE
- **Titular:** 03 // LA PARADOJA ABIERTA
- **Cuerpo:** Mientras geólogos de la Universidad de Estocolmo analizaron muestras de basalto sugiriendo un depósito glacial del Pleistoceno, su simetría geométrica sigue siendo uno de los grandes debates submarinos.
- **Callout Inferior:** ¿QUÉ OPINAS TÚ? LEE EL FINAL →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `High-resolution amber side-scan sonar telemetry and deep-sea ROV spotlight revealing a 60-meter circular monolithic formation on the dark Baltic seafloor, 8k, wide epic perspective with high contrast lighting`

### Slide 05 — CONVERSIÓN & GUARDADOS
- **Titular:** COMENTA "BALTICO"
- **Cuerpo:** Te enviaremos automáticamente por DM el dossier documental completo, las fuentes científicas originales y el análisis extendido de este caso. Guarda este post antes de que desaparezca en tu feed.
- **Callout Inferior:** GUARDA 🔖 • COMPARTE 🚀 • SÍGUENOS @codice.anomalo
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Minimalist dark cyberpunk dossier vault with glowing neon emblem @codice.anomalo`

