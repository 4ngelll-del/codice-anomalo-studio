# 📂 EXPEDIENTE #CA-118 — LA ILUSIÓN DE LA BÓVEDA CELESTE Y LA LUNA GIGANTE

- **Día y Hora Programada (Zona Horaria México):** Sábado a las **21:00 hrs (CDMX)** (Retención Nocturna)
- **Nicho Editorial:** Teorías y Tierra Plana (`COSMOLOGÍA & ÓPTICA`)
- **Palabra Clave de Automatización (ManyChat / DM):** `BOVEDA`
- **Puntuación de Auditoría Multi-Agente:** Originalidad 100% | Retención 97% | Brand Safety 100% | Conversión 97%

---

## 📝 1. CAPTION OFICIAL PARA COPIAR Y PEGAR EN INSTAGRAM

```text
📂 EXPEDIENTE #CA-118: LA ILUSIÓN DE LA BÓVEDA CELESTE Y LA LUNA GIGANTE

Desde las tablillas astronómicas de Babilonia (MUL.APIN) y el techo de Dendera en Egipto hasta los códices mesoamericanos, las culturas antiguas dibujaron el firmamento como un domo elíptico achatado.

🔬 LA EVIDENCIA CLAVE:
La neurociencia visual y el astrónomo Ptolomeo descubrieron por qué: el cerebro humano carece de referencias de profundidad vertical y procesa automáticamente la cúpula celeste como si el horizonte estuviera 3 veces más lejos que el cenit.

👇 ABRO DEBATE EN COMENTARIOS:
Esa geometría perceptual explica por qué cuando la Luna roza el horizonte nuestro córtex visual la interpreta como colosal, aunque una cámara fotográfica mida exactamente los mismos 0.52 grados de arco.

⚡ Comenta la palabra "BOVEDA" y nuestro sistema automático te enviará por DM el dossier extendido, el paper/estudio original y el material complementario.

🔖 Guarda este expediente en tu colección privada para consultarlo más tarde y compártelo en tus historias.

#CodiceAnomalo #TeoríasyTierraPlana #CienciaYTeoria #MisteriosDocumentados #TecnologiaExtrema #Futurologia #DatosInsolitos
```

---

## 🎬 2. GUION DE REEL COMPLEMENTARIO (15 SEGUNDOS — PUENTE DE TRÁFICO AL CARRUSEL)

> **Instrucción de grabación / IA de video:** Usa las imágenes generadas en esta carpeta con efecto Ken Burns (zoom lento) y voz profunda documental:
>
> **Guion:** "¿Te has preguntado por qué todas las civilizaciones antiguas dibujaron el cielo como una cúpula achatada y por qué la Luna se ve gigante en el horizonte aunque mida exactamente lo mismo en una foto? Desliza el carrusel y comenta BOVEDA."

---

## 💰 3. ESTRATEGIA DE MONETIZACIÓN Y AUDITORÍA DE ESTE CARRUSEL

- **Ángulo de Monetización:** Arqueoastronomía / Libros de Historia y Psicología de la Percepción
- **Dictamen de los 4 Agentes:** 100% Brand Safe: Combina historia de la arqueoastronomía con el modelo óptico-cognitivo de Kaufman & Rock (PNAS, 2000).

---

## 🖼️ 4. ESTRUCTURA DETALLADA DE LAS 5 IMÁGENES (1080×1350px 4:5)

### Slide 01 — GANCHO VIRAL
- **Titular:** LA ILUSIÓN DE LA BÓVEDA CELESTE Y LA LUNA GIGANTE
- **Cuerpo:** Por qué 7 civilizaciones antiguas y el ojo humano ven el cielo achatado. El 99% de las personas desconoce los datos verificados detrás de este expediente científico.
- **Callout Inferior:** DESLIZA PARA ABRIR EL EXPEDIENTE →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Ancient Babylonian and Egyptian celestial astrolabe dome glowing with neon magenta constellation geometry over a dark desert ziggurat, archaeoastronomy editorial, 8k`

### Slide 02 — CONTEXTO IMPACTANTE
- **Titular:** 01 // EL HALLAZGO DOCUMENTADO
- **Cuerpo:** Desde las tablillas astronómicas de Babilonia (MUL.APIN) y el techo de Dendera en Egipto hasta los códices mesoamericanos, las culturas antiguas dibujaron el firmamento como un domo elíptico achatado.
- **Callout Inferior:** DATO VERIFICADO // EXPEDIENTE #CA-118
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Ancient Babylonian and Egyptian celestial astrolabe dome glowing with neon magenta constellation geometry over a dark desert ziggurat, archaeoastronomy editorial, 8k, close-up detail shot with technical telemetry overlay`

### Slide 03 — EL GIRO / EVIDENCIA
- **Titular:** 02 // LA ANOMALÍA QUE ROMPE LA LÓGICA
- **Cuerpo:** La neurociencia visual y el astrónomo Ptolomeo descubrieron por qué: el cerebro humano carece de referencias de profundidad vertical y procesa automáticamente la cúpula celeste como si el horizonte estuviera 3 veces más lejos que el cenit.
- **Callout Inferior:** AQUÍ ES DONDE TODO CAMBIA →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Ancient Babylonian and Egyptian celestial astrolabe dome glowing with neon magenta constellation geometry over a dark desert ziggurat, archaeoastronomy editorial, 8k, dramatic side angle showing internal mechanism or anomaly`

### Slide 04 — CLÍMAX & DEBATE
- **Titular:** 03 // LA PARADOJA ABIERTA
- **Cuerpo:** Esa geometría perceptual explica por qué cuando la Luna roza el horizonte nuestro córtex visual la interpreta como colosal, aunque una cámara fotográfica mida exactamente los mismos 0.52 grados de arco.
- **Callout Inferior:** ¿QUÉ OPINAS TÚ? LEE EL FINAL →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Ancient Babylonian and Egyptian celestial astrolabe dome glowing with neon magenta constellation geometry over a dark desert ziggurat, archaeoastronomy editorial, 8k, wide epic perspective with high contrast lighting`

### Slide 05 — CONVERSIÓN & GUARDADOS
- **Titular:** COMENTA "BOVEDA"
- **Cuerpo:** Te enviaremos automáticamente por DM el dossier documental completo, las fuentes científicas originales y el análisis extendido de este caso. Guarda este post antes de que desaparezca en tu feed.
- **Callout Inferior:** GUARDA 🔖 • COMPARTE 🚀 • SÍGUENOS @codice.anomalo
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Minimalist dark cyberpunk dossier vault with glowing neon emblem @codice.anomalo`

