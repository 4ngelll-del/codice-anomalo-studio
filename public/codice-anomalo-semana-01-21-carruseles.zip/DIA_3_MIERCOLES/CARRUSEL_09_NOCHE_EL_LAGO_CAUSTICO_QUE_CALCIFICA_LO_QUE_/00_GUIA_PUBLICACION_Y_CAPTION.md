# 📂 EXPEDIENTE #CA-109 — EL LAGO CÁUSTICO QUE CALCIFICA LO QUE TOCA

- **Día y Hora Programada (Zona Horaria México):** Miércoles a las **21:00 hrs (CDMX)** (Retención Nocturna)
- **Nicho Editorial:** Cosas Insólitas (`FENÓMENO EMPÍRICO`)
- **Palabra Clave de Automatización (ManyChat / DM):** `NATRON`
- **Puntuación de Auditoría Multi-Agente:** Originalidad 100% | Retención 96% | Brand Safety 100% | Conversión 98%

---

## 📝 1. CAPTION OFICIAL PARA COPIAR Y PEGAR EN INSTAGRAM

```text
📂 EXPEDIENTE #CA-109: EL LAGO CÁUSTICO QUE CALCIFICA LO QUE TOCA

Situado en el Gran Valle del Rift en Tanzania y alimentado por las cenizas del volcán Ol Doinyo Lengai —el único del planeta que emite natrocarbonatita—, este lago alcanza los 60 °C.

🔬 LA EVIDENCIA CLAVE:
Sus aguas poseen un pH alcalino de hasta 10.5 (casi tan cáustico como el amoníaco industrial) y están saturadas de carbonato de sodio, el mismo mineral que Egipto usaba para momificar faraones.

👇 ABRO DEBATE EN COMENTARIOS:
Cualquier ave que cae en sus aguas queda preservada en sal calcificada como una estatua de piedra; sin embargo, es la fortaleza donde nacen el 75% de los flamencos menores del mundo.

⚡ Comenta la palabra "NATRON" y nuestro sistema automático te enviará por DM el dossier extendido, el paper/estudio original y el material complementario.

🔖 Guarda este expediente en tu colección privada para consultarlo más tarde y compártelo en tus historias.

#CodiceAnomalo #CosasInsólitas #CienciaYTeoria #MisteriosDocumentados #TecnologiaExtrema #Futurologia #DatosInsolitos
```

---

## 🎬 2. GUION DE REEL COMPLEMENTARIO (15 SEGUNDOS — PUENTE DE TRÁFICO AL CARRUSEL)

> **Instrucción de grabación / IA de video:** Usa las imágenes generadas en esta carpeta con efecto Ken Burns (zoom lento) y voz profunda documental:
>
> **Guion:** "Existe un lago en África tan alcalino y caliente que posee el mismo químico que usaban los egipcios para momificar faraones, y calcifica a los animales que caen en él. Mira las fotografías reales en el carrusel y comenta NATRON."

---

## 💰 3. ESTRATEGIA DE MONETIZACIÓN Y AUDITORÍA DE ESTE CARRUSEL

- **Ángulo de Monetización:** Fotografía Documental / Viajes de Expedición / Marcas Outdoor
- **Dictamen de los 4 Agentes:** Datos geoquímicos verificados del Servicio Geológico y el fotógrafo documental Nick Brandt.

---

## 🖼️ 4. ESTRUCTURA DETALLADA DE LAS 5 IMÁGENES (1080×1350px 4:5)

### Slide 01 — GANCHO VIRAL
- **Titular:** EL LAGO CÁUSTICO QUE CALCIFICA LO QUE TOCA
- **Cuerpo:** Lago Natron: El espejo rojo de pH 10.5 al pie de un volcán activo. El 99% de las personas desconoce los datos verificados detrás de este expediente científico.
- **Callout Inferior:** DESLIZA PARA ABRIR EL EXPEDIENTE →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Crimson and obsidian caustic soda lake in Tanzania reflecting the night sky with calcified crystalline shoreline and Ol Doinyo Lengai volcano in background, dark nature photography, 8k`

### Slide 02 — CONTEXTO IMPACTANTE
- **Titular:** 01 // EL HALLAZGO DOCUMENTADO
- **Cuerpo:** Situado en el Gran Valle del Rift en Tanzania y alimentado por las cenizas del volcán Ol Doinyo Lengai —el único del planeta que emite natrocarbonatita—, este lago alcanza los 60 °C.
- **Callout Inferior:** DATO VERIFICADO // EXPEDIENTE #CA-109
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Crimson and obsidian caustic soda lake in Tanzania reflecting the night sky with calcified crystalline shoreline and Ol Doinyo Lengai volcano in background, dark nature photography, 8k, close-up detail shot with technical telemetry overlay`

### Slide 03 — EL GIRO / EVIDENCIA
- **Titular:** 02 // LA ANOMALÍA QUE ROMPE LA LÓGICA
- **Cuerpo:** Sus aguas poseen un pH alcalino de hasta 10.5 (casi tan cáustico como el amoníaco industrial) y están saturadas de carbonato de sodio, el mismo mineral que Egipto usaba para momificar faraones.
- **Callout Inferior:** AQUÍ ES DONDE TODO CAMBIA →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Crimson and obsidian caustic soda lake in Tanzania reflecting the night sky with calcified crystalline shoreline and Ol Doinyo Lengai volcano in background, dark nature photography, 8k, dramatic side angle showing internal mechanism or anomaly`

### Slide 04 — CLÍMAX & DEBATE
- **Titular:** 03 // LA PARADOJA ABIERTA
- **Cuerpo:** Cualquier ave que cae en sus aguas queda preservada en sal calcificada como una estatua de piedra; sin embargo, es la fortaleza donde nacen el 75% de los flamencos menores del mundo.
- **Callout Inferior:** ¿QUÉ OPINAS TÚ? LEE EL FINAL →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Crimson and obsidian caustic soda lake in Tanzania reflecting the night sky with calcified crystalline shoreline and Ol Doinyo Lengai volcano in background, dark nature photography, 8k, wide epic perspective with high contrast lighting`

### Slide 05 — CONVERSIÓN & GUARDADOS
- **Titular:** COMENTA "NATRON"
- **Cuerpo:** Te enviaremos automáticamente por DM el dossier documental completo, las fuentes científicas originales y el análisis extendido de este caso. Guarda este post antes de que desaparezca en tu feed.
- **Callout Inferior:** GUARDA 🔖 • COMPARTE 🚀 • SÍGUENOS @codice.anomalo
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Minimalist dark cyberpunk dossier vault with glowing neon emblem @codice.anomalo`

