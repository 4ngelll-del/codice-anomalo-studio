# 📂 EXPEDIENTE #CA-119 — PROYECTO HEPHAISTOS: 7 ESTRELLAS CON HUELLA DE DYSON

- **Día y Hora Programada (Zona Horaria México):** Domingo a las **09:00 hrs (CDMX)** (Alto Alcance (CDMX))
- **Nicho Editorial:** Tecnología Extraordinaria (`MEGA-INGENIERÍA`)
- **Palabra Clave de Automatización (ManyChat / DM):** `DYSON`
- **Puntuación de Auditoría Multi-Agente:** Originalidad 100% | Retención 98% | Brand Safety 100% | Conversión 98%

---

## 📝 1. CAPTION OFICIAL PARA COPIAR Y PEGAR EN INSTAGRAM

```text
📂 EXPEDIENTE #CA-119: PROYECTO HEPHAISTOS: 7 ESTRELLAS CON HUELLA DE DYSON

En 1960, el físico Freeman Dyson publicó en la revista Science que una civilización tecnológica avanzada terminaría rodeando su estrella con un enjambre orbital para capturar su energía total.

🔬 LA EVIDENCIA CLAVE:
En 2024, el Proyecto Hephaistos (Universidad de Uppsala) cruzó datos de los satélites Gaia, 2MASS y WISE sobre 5 millones de estrellas buscando el sello termodinámico exacto: exceso de radiación infrarroja.

👇 ABRO DEBATE EN COMENTARIOS:
Tras descartar nebulosas y errores instrumentales, quedaron 7 enanas rojas a menos de 1.000 años luz que emiten hasta 60 veces más calor infrarrojo del que la astrofísica estándar explica.

⚡ Comenta la palabra "DYSON" y nuestro sistema automático te enviará por DM el dossier extendido, el paper/estudio original y el material complementario.

🔖 Guarda este expediente en tu colección privada para consultarlo más tarde y compártelo en tus historias.

#CodiceAnomalo #TecnologíaExtraordinaria #CienciaYTeoria #MisteriosDocumentados #TecnologiaExtrema #Futurologia #DatosInsolitos
```

---

## 🎬 2. GUION DE REEL COMPLEMENTARIO (15 SEGUNDOS — PUENTE DE TRÁFICO AL CARRUSEL)

> **Instrucción de grabación / IA de video:** Usa las imágenes generadas en esta carpeta con efecto Ken Burns (zoom lento) y voz profunda documental:
>
> **Guion:** "Un equipo de astrónomos en Suecia analizó cinco millones de estrellas buscando esferas de Dyson... y encontró siete candidatas reales que emiten un exceso de calor infrarrojo que aún intentan explicar. Lee el estudio en el carrusel y comenta DYSON."

---

## 💰 3. ESTRATEGIA DE MONETIZACIÓN Y AUDITORÍA DE ESTE CARRUSEL

- **Ángulo de Monetización:** Divulgación Aeroespacial / Cursos de Física y Ciencia de Datos
- **Dictamen de los 4 Agentes:** Publicado en Monthly Notices of the Royal Astronomical Society (Matías Suazo et al., Proyecto Hephaistos, mayo 2024).

---

## 🖼️ 4. ESTRUCTURA DETALLADA DE LAS 5 IMÁGENES (1080×1350px 4:5)

### Slide 01 — GANCHO VIRAL
- **Titular:** PROYECTO HEPHAISTOS: 7 ESTRELLAS CON HUELLA DE DYSON
- **Cuerpo:** El estudio astronómico que buscó megaestructuras en 5 millones de soles. El 99% de las personas desconoce los datos verificados detrás de este expediente científico.
- **Callout Inferior:** DESLIZA PARA ABRIR EL EXPEDIENTE →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Colossal hexagonal Dyson swarm megastructure partially enclosing a glowing red-violet star in deep space emitting infrared telemetry rings, epic hard sci-fi, 8k`

### Slide 02 — CONTEXTO IMPACTANTE
- **Titular:** 01 // EL HALLAZGO DOCUMENTADO
- **Cuerpo:** En 1960, el físico Freeman Dyson publicó en la revista Science que una civilización tecnológica avanzada terminaría rodeando su estrella con un enjambre orbital para capturar su energía total.
- **Callout Inferior:** DATO VERIFICADO // EXPEDIENTE #CA-119
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Colossal hexagonal Dyson swarm megastructure partially enclosing a glowing red-violet star in deep space emitting infrared telemetry rings, epic hard sci-fi, 8k, close-up detail shot with technical telemetry overlay`

### Slide 03 — EL GIRO / EVIDENCIA
- **Titular:** 02 // LA ANOMALÍA QUE ROMPE LA LÓGICA
- **Cuerpo:** En 2024, el Proyecto Hephaistos (Universidad de Uppsala) cruzó datos de los satélites Gaia, 2MASS y WISE sobre 5 millones de estrellas buscando el sello termodinámico exacto: exceso de radiación infrarroja.
- **Callout Inferior:** AQUÍ ES DONDE TODO CAMBIA →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Colossal hexagonal Dyson swarm megastructure partially enclosing a glowing red-violet star in deep space emitting infrared telemetry rings, epic hard sci-fi, 8k, dramatic side angle showing internal mechanism or anomaly`

### Slide 04 — CLÍMAX & DEBATE
- **Titular:** 03 // LA PARADOJA ABIERTA
- **Cuerpo:** Tras descartar nebulosas y errores instrumentales, quedaron 7 enanas rojas a menos de 1.000 años luz que emiten hasta 60 veces más calor infrarrojo del que la astrofísica estándar explica.
- **Callout Inferior:** ¿QUÉ OPINAS TÚ? LEE EL FINAL →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Colossal hexagonal Dyson swarm megastructure partially enclosing a glowing red-violet star in deep space emitting infrared telemetry rings, epic hard sci-fi, 8k, wide epic perspective with high contrast lighting`

### Slide 05 — CONVERSIÓN & GUARDADOS
- **Titular:** COMENTA "DYSON"
- **Cuerpo:** Te enviaremos automáticamente por DM el dossier documental completo, las fuentes científicas originales y el análisis extendido de este caso. Guarda este post antes de que desaparezca en tu feed.
- **Callout Inferior:** GUARDA 🔖 • COMPARTE 🚀 • SÍGUENOS @codice.anomalo
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Minimalist dark cyberpunk dossier vault with glowing neon emblem @codice.anomalo`

