# 📂 EXPEDIENTE #CA-111 — EL DUELO ÓPTICO DEL CANAL DE BEDFORD (1838-1870)

- **Día y Hora Programada (Zona Horaria México):** Jueves a las **15:00 hrs (CDMX)** (Debate & Guardados)
- **Nicho Editorial:** Teorías y Tierra Plana (`COSMOLOGÍA & ÓPTICA`)
- **Palabra Clave de Automatización (ManyChat / DM):** `HORIZONTE`
- **Puntuación de Auditoría Multi-Agente:** Originalidad 100% | Retención 98% | Brand Safety 100% | Conversión 95%

---

## 📝 1. CAPTION OFICIAL PARA COPIAR Y PEGAR EN INSTAGRAM

```text
📂 EXPEDIENTE #CA-111: EL DUELO ÓPTICO DEL CANAL DE BEDFORD (1838-1870)

En el verano de 1838, el inventor Samuel Rowbotham se sumergió en el río Old Bedford en Norfolk —un canal recto y sin esclusas de 9.7 km— con un telescopio situado a solo 20 cm sobre el agua.

🔬 LA EVIDENCIA CLAVE:
Rowbotham observó un bote alejarse 9.7 km sin que el casco se ocultara; pero en 1870, el naturalista Alfred Russel Wallace colocó tres miras a 4 metros de altura y demostró que el centro sobresalía.

👇 ABRO DEBATE EN COMENTARIOS:
La física atmosférica moderna probó que ambos vieron cosas reales: a ras del agua fría, la inversión térmica crea un conducto óptico (efecto Fata Morgana) que curva los rayos de luz siguiendo la superficie.

⚡ Comenta la palabra "HORIZONTE" y nuestro sistema automático te enviará por DM el dossier extendido, el paper/estudio original y el material complementario.

🔖 Guarda este expediente en tu colección privada para consultarlo más tarde y compártelo en tus historias.

#CodiceAnomalo #TeoríasyTierraPlana #CienciaYTeoria #MisteriosDocumentados #TecnologiaExtrema #Futurologia #DatosInsolitos
```

---

## 🎬 2. GUION DE REEL COMPLEMENTARIO (15 SEGUNDOS — PUENTE DE TRÁFICO AL CARRUSEL)

> **Instrucción de grabación / IA de video:** Usa las imágenes generadas en esta carpeta con efecto Ken Burns (zoom lento) y voz profunda documental:
>
> **Guion:** "En 1838 y 1870 dos científicos hicieron exactamente el mismo experimento con un telescopio en un canal recto de diez kilómetros en Inglaterra... y obtuvieron resultados opuestos. Descubre qué ocurrió con la luz en el carrusel y comenta HORIZONTE."

---

## 💰 3. ESTRATEGIA DE MONETIZACIÓN Y AUDITORÍA DE ESTE CARRUSEL

- **Ángulo de Monetización:** Óptica / Fotografía de Larga Distancia / Educación Científica
- **Dictamen de los 4 Agentes:** 100% Brand Safe: Crónica histórica exacta del experimento de Bedford Level (Rowbotham 1838 vs Wallace 1870) y refracción atmosférica.

---

## 🖼️ 4. ESTRUCTURA DETALLADA DE LAS 5 IMÁGENES (1080×1350px 4:5)

### Slide 01 — GANCHO VIRAL
- **Titular:** EL DUELO ÓPTICO DEL CANAL DE BEDFORD (1838-1870)
- **Cuerpo:** El experimento real con telescopios que dividió la percepción del horizonte. El 99% de las personas desconoce los datos verificados detrás de este expediente científico.
- **Callout Inferior:** DESLIZA PARA ABRIR EL EXPEDIENTE →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Precision laser beam and telescope setup across a dead-calm dark mirror canal at twilight illustrating atmospheric thermal refraction layers, scientific documentary visualization, 8k`

### Slide 02 — CONTEXTO IMPACTANTE
- **Titular:** 01 // EL HALLAZGO DOCUMENTADO
- **Cuerpo:** En el verano de 1838, el inventor Samuel Rowbotham se sumergió en el río Old Bedford en Norfolk —un canal recto y sin esclusas de 9.7 km— con un telescopio situado a solo 20 cm sobre el agua.
- **Callout Inferior:** DATO VERIFICADO // EXPEDIENTE #CA-111
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Precision laser beam and telescope setup across a dead-calm dark mirror canal at twilight illustrating atmospheric thermal refraction layers, scientific documentary visualization, 8k, close-up detail shot with technical telemetry overlay`

### Slide 03 — EL GIRO / EVIDENCIA
- **Titular:** 02 // LA ANOMALÍA QUE ROMPE LA LÓGICA
- **Cuerpo:** Rowbotham observó un bote alejarse 9.7 km sin que el casco se ocultara; pero en 1870, el naturalista Alfred Russel Wallace colocó tres miras a 4 metros de altura y demostró que el centro sobresalía.
- **Callout Inferior:** AQUÍ ES DONDE TODO CAMBIA →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Precision laser beam and telescope setup across a dead-calm dark mirror canal at twilight illustrating atmospheric thermal refraction layers, scientific documentary visualization, 8k, dramatic side angle showing internal mechanism or anomaly`

### Slide 04 — CLÍMAX & DEBATE
- **Titular:** 03 // LA PARADOJA ABIERTA
- **Cuerpo:** La física atmosférica moderna probó que ambos vieron cosas reales: a ras del agua fría, la inversión térmica crea un conducto óptico (efecto Fata Morgana) que curva los rayos de luz siguiendo la superficie.
- **Callout Inferior:** ¿QUÉ OPINAS TÚ? LEE EL FINAL →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Precision laser beam and telescope setup across a dead-calm dark mirror canal at twilight illustrating atmospheric thermal refraction layers, scientific documentary visualization, 8k, wide epic perspective with high contrast lighting`

### Slide 05 — CONVERSIÓN & GUARDADOS
- **Titular:** COMENTA "HORIZONTE"
- **Cuerpo:** Te enviaremos automáticamente por DM el dossier documental completo, las fuentes científicas originales y el análisis extendido de este caso. Guarda este post antes de que desaparezca en tu feed.
- **Callout Inferior:** GUARDA 🔖 • COMPARTE 🚀 • SÍGUENOS @codice.anomalo
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Minimalist dark cyberpunk dossier vault with glowing neon emblem @codice.anomalo`

