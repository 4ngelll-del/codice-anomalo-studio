# 📂 EXPEDIENTE #CA-110 — EL MECANISMO DE ANTICITERA BAJO RAYOS X

- **Día y Hora Programada (Zona Horaria México):** Jueves a las **09:00 hrs (CDMX)** (Alto Alcance (CDMX))
- **Nicho Editorial:** Misterios Sin Resolver (`EXPEDIENTE ABIERTO`)
- **Palabra Clave de Automatización (ManyChat / DM):** `ANTICITERA`
- **Puntuación de Auditoría Multi-Agente:** Originalidad 100% | Retención 97% | Brand Safety 100% | Conversión 99%

---

## 📝 1. CAPTION OFICIAL PARA COPIAR Y PEGAR EN INSTAGRAM

```text
📂 EXPEDIENTE #CA-110: EL MECANISMO DE ANTICITERA BAJO RAYOS X

Rescatado en 1901 a 45 metros de profundidad en un naufragio romano del siglo I a.C., este bloque corroído parecía una pieza menor hasta que fue escaneado con tomografía de rayos X de 8 toneladas.

🔬 LA EVIDENCIA CLAVE:
Los escáneres del University College London revelaron 37 engranajes epicicloidales con dientes triangulares de 1.5 milímetros capaces de calcular la órbita elíptica de la Luna y el ciclo Saros de eclipses.

👇 ABRO DEBATE EN COMENTARIOS:
La paradoja histórica aún no tiene respuesta: ningún otro mecanismo con engranajes diferenciales de esa precisión volvió a construirse en la Tierra hasta los relojes europeos del siglo XIV.

⚡ Comenta la palabra "ANTICITERA" y nuestro sistema automático te enviará por DM el dossier extendido, el paper/estudio original y el material complementario.

🔖 Guarda este expediente en tu colección privada para consultarlo más tarde y compártelo en tus historias.

#CodiceAnomalo #MisteriosSinResolver #CienciaYTeoria #MisteriosDocumentados #TecnologiaExtrema #Futurologia #DatosInsolitos
```

---

## 🎬 2. GUION DE REEL COMPLEMENTARIO (15 SEGUNDOS — PUENTE DE TRÁFICO AL CARRUSEL)

> **Instrucción de grabación / IA de video:** Usa las imágenes generadas en esta carpeta con efecto Ken Burns (zoom lento) y voz profunda documental:
>
> **Guion:** "Cuando metieron este trozo de bronce de hace dos mil años en un escáner de rayos X, descubrieron una computadora de 37 engranajes que no debería haber existido hasta 1.500 años después. Ve la reconstrucción 3D en el post y comenta ANTICITERA."

---

## 💰 3. ESTRATEGIA DE MONETIZACIÓN Y AUDITORÍA DE ESTE CARRUSEL

- **Ángulo de Monetización:** Relojería / Ingeniería Mecánica / Coleccionables Históricos
- **Dictamen de los 4 Agentes:** Auditado con la reconstrucción de Tony Freeth et al. (UCL Antikythera Research Team, Scientific Reports 2021).

---

## 🖼️ 4. ESTRUCTURA DETALLADA DE LAS 5 IMÁGENES (1080×1350px 4:5)

### Slide 01 — GANCHO VIRAL
- **Titular:** EL MECANISMO DE ANTICITERA BAJO RAYOS X
- **Cuerpo:** La computadora astronómica de bronce 1.500 años adelantada a su época. El 99% de las personas desconoce los datos verificados detrás de este expediente científico.
- **Callout Inferior:** DESLIZA PARA ABRIR EL EXPEDIENTE →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Ancient Greek bronze astronomical geared computer mechanism floating in dark void with golden X-ray holographic planetary orbits and epigraphic inscriptions, 8k`

### Slide 02 — CONTEXTO IMPACTANTE
- **Titular:** 01 // EL HALLAZGO DOCUMENTADO
- **Cuerpo:** Rescatado en 1901 a 45 metros de profundidad en un naufragio romano del siglo I a.C., este bloque corroído parecía una pieza menor hasta que fue escaneado con tomografía de rayos X de 8 toneladas.
- **Callout Inferior:** DATO VERIFICADO // EXPEDIENTE #CA-110
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Ancient Greek bronze astronomical geared computer mechanism floating in dark void with golden X-ray holographic planetary orbits and epigraphic inscriptions, 8k, close-up detail shot with technical telemetry overlay`

### Slide 03 — EL GIRO / EVIDENCIA
- **Titular:** 02 // LA ANOMALÍA QUE ROMPE LA LÓGICA
- **Cuerpo:** Los escáneres del University College London revelaron 37 engranajes epicicloidales con dientes triangulares de 1.5 milímetros capaces de calcular la órbita elíptica de la Luna y el ciclo Saros de eclipses.
- **Callout Inferior:** AQUÍ ES DONDE TODO CAMBIA →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Ancient Greek bronze astronomical geared computer mechanism floating in dark void with golden X-ray holographic planetary orbits and epigraphic inscriptions, 8k, dramatic side angle showing internal mechanism or anomaly`

### Slide 04 — CLÍMAX & DEBATE
- **Titular:** 03 // LA PARADOJA ABIERTA
- **Cuerpo:** La paradoja histórica aún no tiene respuesta: ningún otro mecanismo con engranajes diferenciales de esa precisión volvió a construirse en la Tierra hasta los relojes europeos del siglo XIV.
- **Callout Inferior:** ¿QUÉ OPINAS TÚ? LEE EL FINAL →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Ancient Greek bronze astronomical geared computer mechanism floating in dark void with golden X-ray holographic planetary orbits and epigraphic inscriptions, 8k, wide epic perspective with high contrast lighting`

### Slide 05 — CONVERSIÓN & GUARDADOS
- **Titular:** COMENTA "ANTICITERA"
- **Cuerpo:** Te enviaremos automáticamente por DM el dossier documental completo, las fuentes científicas originales y el análisis extendido de este caso. Guarda este post antes de que desaparezca en tu feed.
- **Callout Inferior:** GUARDA 🔖 • COMPARTE 🚀 • SÍGUENOS @codice.anomalo
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Minimalist dark cyberpunk dossier vault with glowing neon emblem @codice.anomalo`

