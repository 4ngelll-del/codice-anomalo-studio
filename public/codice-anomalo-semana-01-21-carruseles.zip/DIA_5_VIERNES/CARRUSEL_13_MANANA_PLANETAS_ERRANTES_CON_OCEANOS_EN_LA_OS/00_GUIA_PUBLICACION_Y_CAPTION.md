# 📂 EXPEDIENTE #CA-113 — PLANETAS ERRANTES CON OCÉANOS EN LA OSCURIDAD

- **Día y Hora Programada (Zona Horaria México):** Viernes a las **09:00 hrs (CDMX)** (Alto Alcance (CDMX))
- **Nicho Editorial:** Espacio Sideral (`COSMOS PROFUNDO`)
- **Palabra Clave de Automatización (ManyChat / DM):** `ERRANTE`
- **Puntuación de Auditoría Multi-Agente:** Originalidad 100% | Retención 96% | Brand Safety 100% | Conversión 97%

---

## 📝 1. CAPTION OFICIAL PARA COPIAR Y PEGAR EN INSTAGRAM

```text
📂 EXPEDIENTE #CA-113: PLANETAS ERRANTES CON OCÉANOS EN LA OSCURIDAD

Mediante microlentes gravitacionales y el telescopio James Webb, los astrofísicos estiman que existen hasta 20 veces más planetas huérfanos vagando en la oscuridad interestelar que estrellas en la galaxia.

🔬 LA EVIDENCIA CLAVE:
El físico David Stevenson (Caltech) demostró que un planeta errante expulsado de su sistema puede conservar una atmósfera densa de hidrógeno molecular y calor radiactivo interno durante miles de millones de años.

👇 ABRO DEBATE EN COMENTARIOS:
Bajo una corteza de hielo aislante de varios kilómetros, esa presión geotérmica mantiene océanos líquidos completos en absoluta oscuridad: auténticas arcas biológicas interestelares.

⚡ Comenta la palabra "ERRANTE" y nuestro sistema automático te enviará por DM el dossier extendido, el paper/estudio original y el material complementario.

🔖 Guarda este expediente en tu colección privada para consultarlo más tarde y compártelo en tus historias.

#CodiceAnomalo #EspacioSideral #CienciaYTeoria #MisteriosDocumentados #TecnologiaExtrema #Futurologia #DatosInsolitos
```

---

## 🎬 2. GUION DE REEL COMPLEMENTARIO (15 SEGUNDOS — PUENTE DE TRÁFICO AL CARRUSEL)

> **Instrucción de grabación / IA de video:** Usa las imágenes generadas en esta carpeta con efecto Ken Burns (zoom lento) y voz profunda documental:
>
> **Guion:** "En la oscuridad total entre las estrellas viajan miles de millones de planetas sin sol. Lo increíble es que bajo su hielo pueden tener océanos líquidos calientes con vida. Desliza el nuevo carrusel y comenta ERRANTE."

---

## 💰 3. ESTRATEGIA DE MONETIZACIÓN Y AUDITORÍA DE ESTE CARRUSEL

- **Ángulo de Monetización:** Astrobiología / Libros Sci-Fi & Ciencia / Planetarios
- **Dictamen de los 4 Agentes:** Fundamentado en el paper de David J. Stevenson (Nature, 1999: "Life-sustaining planets in interstellar space") y hallazgos de JWST.

---

## 🖼️ 4. ESTRUCTURA DETALLADA DE LAS 5 IMÁGENES (1080×1350px 4:5)

### Slide 01 — GANCHO VIRAL
- **Titular:** PLANETAS ERRANTES CON OCÉANOS EN LA OSCURIDAD
- **Cuerpo:** Mundos sin estrella que viajan solos por la Vía Láctea con agua líquida. El 99% de las personas desconoce los datos verificados detrás de este expediente científico.
- **Callout Inferior:** DESLIZA PARA ABRIR EL EXPEDIENTE →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Rogue icy planet drifting in pitch-black interstellar space without a sun, glowing hydrothermal vents visible through deep sub-surface ice fissures, cinematic space art, 8k`

### Slide 02 — CONTEXTO IMPACTANTE
- **Titular:** 01 // EL HALLAZGO DOCUMENTADO
- **Cuerpo:** Mediante microlentes gravitacionales y el telescopio James Webb, los astrofísicos estiman que existen hasta 20 veces más planetas huérfanos vagando en la oscuridad interestelar que estrellas en la galaxia.
- **Callout Inferior:** DATO VERIFICADO // EXPEDIENTE #CA-113
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Rogue icy planet drifting in pitch-black interstellar space without a sun, glowing hydrothermal vents visible through deep sub-surface ice fissures, cinematic space art, 8k, close-up detail shot with technical telemetry overlay`

### Slide 03 — EL GIRO / EVIDENCIA
- **Titular:** 02 // LA ANOMALÍA QUE ROMPE LA LÓGICA
- **Cuerpo:** El físico David Stevenson (Caltech) demostró que un planeta errante expulsado de su sistema puede conservar una atmósfera densa de hidrógeno molecular y calor radiactivo interno durante miles de millones de años.
- **Callout Inferior:** AQUÍ ES DONDE TODO CAMBIA →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Rogue icy planet drifting in pitch-black interstellar space without a sun, glowing hydrothermal vents visible through deep sub-surface ice fissures, cinematic space art, 8k, dramatic side angle showing internal mechanism or anomaly`

### Slide 04 — CLÍMAX & DEBATE
- **Titular:** 03 // LA PARADOJA ABIERTA
- **Cuerpo:** Bajo una corteza de hielo aislante de varios kilómetros, esa presión geotérmica mantiene océanos líquidos completos en absoluta oscuridad: auténticas arcas biológicas interestelares.
- **Callout Inferior:** ¿QUÉ OPINAS TÚ? LEE EL FINAL →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Rogue icy planet drifting in pitch-black interstellar space without a sun, glowing hydrothermal vents visible through deep sub-surface ice fissures, cinematic space art, 8k, wide epic perspective with high contrast lighting`

### Slide 05 — CONVERSIÓN & GUARDADOS
- **Titular:** COMENTA "ERRANTE"
- **Cuerpo:** Te enviaremos automáticamente por DM el dossier documental completo, las fuentes científicas originales y el análisis extendido de este caso. Guarda este post antes de que desaparezca en tu feed.
- **Callout Inferior:** GUARDA 🔖 • COMPARTE 🚀 • SÍGUENOS @codice.anomalo
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Minimalist dark cyberpunk dossier vault with glowing neon emblem @codice.anomalo`

