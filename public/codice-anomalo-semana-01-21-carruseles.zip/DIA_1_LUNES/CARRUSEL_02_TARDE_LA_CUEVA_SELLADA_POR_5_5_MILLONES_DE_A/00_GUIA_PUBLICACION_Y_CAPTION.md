# 📂 EXPEDIENTE #CA-102 — LA CUEVA SELLADA POR 5.5 MILLONES DE AÑOS

- **Día y Hora Programada (Zona Horaria México):** Lunes a las **15:00 hrs (CDMX)** (Debate & Guardados)
- **Nicho Editorial:** Cosas Insólitas (`FENÓMENO EMPÍRICO`)
- **Palabra Clave de Automatización (ManyChat / DM):** `MOVILE`
- **Puntuación de Auditoría Multi-Agente:** Originalidad 100% | Retención 97% | Brand Safety 100% | Conversión 96%

---

## 📝 1. CAPTION OFICIAL PARA COPIAR Y PEGAR EN INSTAGRAM

```text
📂 EXPEDIENTE #CA-102: LA CUEVA SELLADA POR 5.5 MILLONES DE AÑOS

En 1986, perforaciones geotécnicas cerca del Mar Negro en Rumania abrieron una caverna que permaneció herméticamente aislada de la atmósfera y del Sol durante 5.5 millones de años.

🔬 LA EVIDENCIA CLAVE:
En su interior habitan 48 especies ciegas y translúcidas nunca vistas en la superficie que sobreviven con apenas 7% de oxígeno alimentándose de una espuma bacteriana quimiosintética.

👇 ABRO DEBATE EN COMENTARIOS:
La NASA estudia este enclave bajo estricto protocolo de cuarentena porque demuestra empíricamente cómo podría prosperar la vida compleja bajo el océano congelado de Europa o Encélado.

⚡ Comenta la palabra "MOVILE" y nuestro sistema automático te enviará por DM el dossier extendido, el paper/estudio original y el material complementario.

🔖 Guarda este expediente en tu colección privada para consultarlo más tarde y compártelo en tus historias.

#CodiceAnomalo #CosasInsólitas #CienciaYTeoria #MisteriosDocumentados #TecnologiaExtrema #Futurologia #DatosInsolitos
```

---

## 🎬 2. GUION DE REEL COMPLEMENTARIO (15 SEGUNDOS — PUENTE DE TRÁFICO AL CARRUSEL)

> **Instrucción de grabación / IA de video:** Usa las imágenes generadas en esta carpeta con efecto Ken Burns (zoom lento) y voz profunda documental:
>
> **Guion:** "En Rumania abrieron por accidente una cueva que estuvo sellada durante cinco millones y medio de años sin una sola gota de luz solar, y encontraron 33 especies que no existen en el resto de la Tierra. Mira las 5 fotos en el post del perfil y comenta MOVILE."

---

## 💰 3. ESTRATEGIA DE MONETIZACIÓN Y AUDITORÍA DE ESTE CARRUSEL

- **Ángulo de Monetización:** Documentales Premium / Patrocinios de Divulgación Científica
- **Dictamen de los 4 Agentes:** Datos verificados del Instituto de Espeleología Emil Racoviță (Cristian Lascu, 1986). Retención estimada: 98%.

---

## 🖼️ 4. ESTRUCTURA DETALLADA DE LAS 5 IMÁGENES (1080×1350px 4:5)

### Slide 01 — GANCHO VIRAL
- **Titular:** LA CUEVA SELLADA POR 5.5 MILLONES DE AÑOS
- **Cuerpo:** Movile: El ecosistema subterráneo que respira ácido sulfhídrico. El 99% de las personas desconoce los datos verificados detrás de este expediente científico.
- **Callout Inferior:** DESLIZA PARA ABRIR EL EXPEDIENTE →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Subterranean sealed toxic sulfur cave in Romania with bioluminescent bacterial mat floating on dark obsidian water, eerie emerald glow, National Geographic dark editorial, 8k`

### Slide 02 — CONTEXTO IMPACTANTE
- **Titular:** 01 // EL HALLAZGO DOCUMENTADO
- **Cuerpo:** En 1986, perforaciones geotécnicas cerca del Mar Negro en Rumania abrieron una caverna que permaneció herméticamente aislada de la atmósfera y del Sol durante 5.5 millones de años.
- **Callout Inferior:** DATO VERIFICADO // EXPEDIENTE #CA-102
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Subterranean sealed toxic sulfur cave in Romania with bioluminescent bacterial mat floating on dark obsidian water, eerie emerald glow, National Geographic dark editorial, 8k, close-up detail shot with technical telemetry overlay`

### Slide 03 — EL GIRO / EVIDENCIA
- **Titular:** 02 // LA ANOMALÍA QUE ROMPE LA LÓGICA
- **Cuerpo:** En su interior habitan 48 especies ciegas y translúcidas nunca vistas en la superficie que sobreviven con apenas 7% de oxígeno alimentándose de una espuma bacteriana quimiosintética.
- **Callout Inferior:** AQUÍ ES DONDE TODO CAMBIA →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Subterranean sealed toxic sulfur cave in Romania with bioluminescent bacterial mat floating on dark obsidian water, eerie emerald glow, National Geographic dark editorial, 8k, dramatic side angle showing internal mechanism or anomaly`

### Slide 04 — CLÍMAX & DEBATE
- **Titular:** 03 // LA PARADOJA ABIERTA
- **Cuerpo:** La NASA estudia este enclave bajo estricto protocolo de cuarentena porque demuestra empíricamente cómo podría prosperar la vida compleja bajo el océano congelado de Europa o Encélado.
- **Callout Inferior:** ¿QUÉ OPINAS TÚ? LEE EL FINAL →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Subterranean sealed toxic sulfur cave in Romania with bioluminescent bacterial mat floating on dark obsidian water, eerie emerald glow, National Geographic dark editorial, 8k, wide epic perspective with high contrast lighting`

### Slide 05 — CONVERSIÓN & GUARDADOS
- **Titular:** COMENTA "MOVILE"
- **Cuerpo:** Te enviaremos automáticamente por DM el dossier documental completo, las fuentes científicas originales y el análisis extendido de este caso. Guarda este post antes de que desaparezca en tu feed.
- **Callout Inferior:** GUARDA 🔖 • COMPARTE 🚀 • SÍGUENOS @codice.anomalo
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Minimalist dark cyberpunk dossier vault with glowing neon emblem @codice.anomalo`

