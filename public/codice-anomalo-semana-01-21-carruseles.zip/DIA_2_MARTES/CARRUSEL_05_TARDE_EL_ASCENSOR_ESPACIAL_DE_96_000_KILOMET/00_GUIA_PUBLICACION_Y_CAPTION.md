# 📂 EXPEDIENTE #CA-105 — EL ASCENSOR ESPACIAL DE 96.000 KILÓMETROS

- **Día y Hora Programada (Zona Horaria México):** Martes a las **15:00 hrs (CDMX)** (Debate & Guardados)
- **Nicho Editorial:** Tecnología Extraordinaria (`MEGA-INGENIERÍA`)
- **Palabra Clave de Automatización (ManyChat / DM):** `ORBITAL`
- **Puntuación de Auditoría Multi-Agente:** Originalidad 100% | Retención 96% | Brand Safety 100% | Conversión 99%

---

## 📝 1. CAPTION OFICIAL PARA COPIAR Y PEGAR EN INSTAGRAM

```text
📂 EXPEDIENTE #CA-105: EL ASCENSOR ESPACIAL DE 96.000 KILÓMETROS

La corporación Obayashi de Tokio —constructora de la torre Tokyo Skytree— mantiene activo su diseño de ingeniería para desplegar un cable orbital desde el ecuador terrestre hacia el año 2050.

🔬 LA EVIDENCIA CLAVE:
Utilizando cintas de nanotubos de carbono con una resistencia a la tracción superior a 60 gigapascales, cabinas electromagnéticas reducirían el costo por kilo en órbita de $2,500 a solo $57 dólares.

👇 ABRO DEBATE EN COMENTARIOS:
La física orbital de Tsiolkovski ya está resuelta; la carrera actual en los laboratorios cuánticos consiste en tejer el filamento de carbono continuo sin defectos a escala atómica.

⚡ Comenta la palabra "ORBITAL" y nuestro sistema automático te enviará por DM el dossier extendido, el paper/estudio original y el material complementario.

🔖 Guarda este expediente en tu colección privada para consultarlo más tarde y compártelo en tus historias.

#CodiceAnomalo #TecnologíaExtraordinaria #CienciaYTeoria #MisteriosDocumentados #TecnologiaExtrema #Futurologia #DatosInsolitos
```

---

## 🎬 2. GUION DE REEL COMPLEMENTARIO (15 SEGUNDOS — PUENTE DE TRÁFICO AL CARRUSEL)

> **Instrucción de grabación / IA de video:** Usa las imágenes generadas en esta carpeta con efecto Ken Burns (zoom lento) y voz profunda documental:
>
> **Guion:** "Enviar un kilo al espacio cuesta miles de dólares con cohetes, pero una megacorporación en Tokio ya diseñó un cable de nanotubos de carbono de 96 mil kilómetros para subir en ascensor por 57 dólares. Mira los planos en el carrusel y comenta ORBITAL."

---

## 💰 3. ESTRATEGIA DE MONETIZACIÓN Y AUDITORÍA DE ESTE CARRUSEL

- **Ángulo de Monetización:** Patrocinios de Ingeniería, Inversión en DeepTech y Cursos STEM
- **Dictamen de los 4 Agentes:** Verificado con especificaciones oficiales de Obayashi Corporation (Proyecto Space Elevator 2050) y experimentos STARS en la ISS.

---

## 🖼️ 4. ESTRUCTURA DETALLADA DE LAS 5 IMÁGENES (1080×1350px 4:5)

### Slide 01 — GANCHO VIRAL
- **Titular:** EL ASCENSOR ESPACIAL DE 96.000 KILÓMETROS
- **Cuerpo:** El proyecto japonés para subir al espacio sin usar un solo cohete. El 99% de las personas desconoce los datos verificados detrás de este expediente científico.
- **Callout Inferior:** DESLIZA PARA ABRIR EL EXPEDIENTE →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Futuristic carbon nanotube space elevator tether rising from an equatorial ocean mega-platform into the dark stratosphere with violet laser power beams, hard sci-fi engineering, 8k`

### Slide 02 — CONTEXTO IMPACTANTE
- **Titular:** 01 // EL HALLAZGO DOCUMENTADO
- **Cuerpo:** La corporación Obayashi de Tokio —constructora de la torre Tokyo Skytree— mantiene activo su diseño de ingeniería para desplegar un cable orbital desde el ecuador terrestre hacia el año 2050.
- **Callout Inferior:** DATO VERIFICADO // EXPEDIENTE #CA-105
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Futuristic carbon nanotube space elevator tether rising from an equatorial ocean mega-platform into the dark stratosphere with violet laser power beams, hard sci-fi engineering, 8k, close-up detail shot with technical telemetry overlay`

### Slide 03 — EL GIRO / EVIDENCIA
- **Titular:** 02 // LA ANOMALÍA QUE ROMPE LA LÓGICA
- **Cuerpo:** Utilizando cintas de nanotubos de carbono con una resistencia a la tracción superior a 60 gigapascales, cabinas electromagnéticas reducirían el costo por kilo en órbita de $2,500 a solo $57 dólares.
- **Callout Inferior:** AQUÍ ES DONDE TODO CAMBIA →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Futuristic carbon nanotube space elevator tether rising from an equatorial ocean mega-platform into the dark stratosphere with violet laser power beams, hard sci-fi engineering, 8k, dramatic side angle showing internal mechanism or anomaly`

### Slide 04 — CLÍMAX & DEBATE
- **Titular:** 03 // LA PARADOJA ABIERTA
- **Cuerpo:** La física orbital de Tsiolkovski ya está resuelta; la carrera actual en los laboratorios cuánticos consiste en tejer el filamento de carbono continuo sin defectos a escala atómica.
- **Callout Inferior:** ¿QUÉ OPINAS TÚ? LEE EL FINAL →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Futuristic carbon nanotube space elevator tether rising from an equatorial ocean mega-platform into the dark stratosphere with violet laser power beams, hard sci-fi engineering, 8k, wide epic perspective with high contrast lighting`

### Slide 05 — CONVERSIÓN & GUARDADOS
- **Titular:** COMENTA "ORBITAL"
- **Cuerpo:** Te enviaremos automáticamente por DM el dossier documental completo, las fuentes científicas originales y el análisis extendido de este caso. Guarda este post antes de que desaparezca en tu feed.
- **Callout Inferior:** GUARDA 🔖 • COMPARTE 🚀 • SÍGUENOS @codice.anomalo
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Minimalist dark cyberpunk dossier vault with glowing neon emblem @codice.anomalo`

