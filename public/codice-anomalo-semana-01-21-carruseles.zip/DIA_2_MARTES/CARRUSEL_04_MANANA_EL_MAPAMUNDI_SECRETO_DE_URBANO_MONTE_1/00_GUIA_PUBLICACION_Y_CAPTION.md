# 📂 EXPEDIENTE #CA-104 — EL MAPAMUNDI SECRETO DE URBANO MONTE (1587)

- **Día y Hora Programada (Zona Horaria México):** Martes a las **09:00 hrs (CDMX)** (Alto Alcance (CDMX))
- **Nicho Editorial:** Teorías y Tierra Plana (`COSMOLOGÍA & ÓPTICA`)
- **Palabra Clave de Automatización (ManyChat / DM):** `MAPAMUNDI`
- **Puntuación de Auditoría Multi-Agente:** Originalidad 100% | Retención 99% | Brand Safety 100% | Conversión 98%

---

## 📝 1. CAPTION OFICIAL PARA COPIAR Y PEGAR EN INSTAGRAM

```text
📂 EXPEDIENTE #CA-104: EL MAPAMUNDI SECRETO DE URBANO MONTE (1587)

Conservado en la Universidad de Stanford, este colosal planisferio manuscrito de casi 3 metros de diámetro trazado en Milán en 1587 proyecta el mundo como un disco centrado en el Polo Norte.

🔬 LA EVIDENCIA CLAVE:
Urbano Monte utilizó una proyección azimutal polar matemática: conserva las rutas meridianas reales desde el centro, pero deforma la Antártida hasta convertirla en un anillo exterior gigante.

👇 ABRO DEBATE EN COMENTARIOS:
Cuando este mapa se digitalizó en alta resolución, desató el debate cartográfico más viral del siglo XXI entre historiadores de la geometría esférica y teóricos de modelos alternativos.

⚡ Comenta la palabra "MAPAMUNDI" y nuestro sistema automático te enviará por DM el dossier extendido, el paper/estudio original y el material complementario.

🔖 Guarda este expediente en tu colección privada para consultarlo más tarde y compártelo en tus historias.

#CodiceAnomalo #TeoríasyTierraPlana #CienciaYTeoria #MisteriosDocumentados #TecnologiaExtrema #Futurologia #DatosInsolitos
```

---

## 🎬 2. GUION DE REEL COMPLEMENTARIO (15 SEGUNDOS — PUENTE DE TRÁFICO AL CARRUSEL)

> **Instrucción de grabación / IA de video:** Usa las imágenes generadas en esta carpeta con efecto Ken Burns (zoom lento) y voz profunda documental:
>
> **Guion:** "En 1587, un cartógrafo en Milán dibujó un mapa de 60 páginas que estuvo oculto por siglos y muestra la Tierra como un disco polar perfecto. Hoy está digitalizado en Stanford y explica el debate más viral de internet. Comenta MAPAMUNDI para enviarte el archivo en ultra alta resolución."

---

## 💰 3. ESTRATEGIA DE MONETIZACIÓN Y AUDITORÍA DE ESTE CARRUSEL

- **Ángulo de Monetización:** Lead Magnet Dossier Histórico / Afiliación de Mapas y Arte Editorial
- **Dictamen de los 4 Agentes:** 100% Brand Safe: Enmarcado en la David Rumsey Map Collection de la Universidad de Stanford. Altísima viralidad en comentarios.

---

## 🖼️ 4. ESTRUCTURA DETALLADA DE LAS 5 IMÁGENES (1080×1350px 4:5)

### Slide 01 — GANCHO VIRAL
- **Titular:** EL MAPAMUNDI SECRETO DE URBANO MONTE (1587)
- **Cuerpo:** Por qué el Renacimiento dibujó la Tierra como un disco polar de 60 hojas. El 99% de las personas desconoce los datos verificados detrás de este expediente científico.
- **Callout Inferior:** DESLIZA PARA ABRIR EL EXPEDIENTE →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Ancient 1587 Urbano Monte azimuthal polar world map manuscript glowing with neon magenta geometric projection lines on dark obsidian desk, hyper detailed archival photography, 8k`

### Slide 02 — CONTEXTO IMPACTANTE
- **Titular:** 01 // EL HALLAZGO DOCUMENTADO
- **Cuerpo:** Conservado en la Universidad de Stanford, este colosal planisferio manuscrito de casi 3 metros de diámetro trazado en Milán en 1587 proyecta el mundo como un disco centrado en el Polo Norte.
- **Callout Inferior:** DATO VERIFICADO // EXPEDIENTE #CA-104
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Ancient 1587 Urbano Monte azimuthal polar world map manuscript glowing with neon magenta geometric projection lines on dark obsidian desk, hyper detailed archival photography, 8k, close-up detail shot with technical telemetry overlay`

### Slide 03 — EL GIRO / EVIDENCIA
- **Titular:** 02 // LA ANOMALÍA QUE ROMPE LA LÓGICA
- **Cuerpo:** Urbano Monte utilizó una proyección azimutal polar matemática: conserva las rutas meridianas reales desde el centro, pero deforma la Antártida hasta convertirla en un anillo exterior gigante.
- **Callout Inferior:** AQUÍ ES DONDE TODO CAMBIA →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Ancient 1587 Urbano Monte azimuthal polar world map manuscript glowing with neon magenta geometric projection lines on dark obsidian desk, hyper detailed archival photography, 8k, dramatic side angle showing internal mechanism or anomaly`

### Slide 04 — CLÍMAX & DEBATE
- **Titular:** 03 // LA PARADOJA ABIERTA
- **Cuerpo:** Cuando este mapa se digitalizó en alta resolución, desató el debate cartográfico más viral del siglo XXI entre historiadores de la geometría esférica y teóricos de modelos alternativos.
- **Callout Inferior:** ¿QUÉ OPINAS TÚ? LEE EL FINAL →
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Ancient 1587 Urbano Monte azimuthal polar world map manuscript glowing with neon magenta geometric projection lines on dark obsidian desk, hyper detailed archival photography, 8k, wide epic perspective with high contrast lighting`

### Slide 05 — CONVERSIÓN & GUARDADOS
- **Titular:** COMENTA "MAPAMUNDI"
- **Cuerpo:** Te enviaremos automáticamente por DM el dossier documental completo, las fuentes científicas originales y el análisis extendido de este caso. Guarda este post antes de que desaparezca en tu feed.
- **Callout Inferior:** GUARDA 🔖 • COMPARTE 🚀 • SÍGUENOS @codice.anomalo
- **Prompt de Imagen IA (Midjourney / Flux / Imagen 3):** `Minimalist dark cyberpunk dossier vault with glowing neon emblem @codice.anomalo`

